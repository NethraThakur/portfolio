# Nethra Thakur — Portfolio

A personal portfolio built with React, Vite, Tailwind CSS and Framer Motion. Living
ambient background, editorial project panels with custom animated visuals (no fake
screenshots), and a subtle gaming-inspired system aesthetic.

## Run locally

```bash
npm install
npm run dev
```

Open the printed local URL (usually `http://localhost:5173`).

## Build for production

```bash
npm run build
npm run preview   # optional, serves the production build locally
```

The production build is written to `dist/`.

## Structure

```
src/
  components/
    AmbientBackground.jsx   living layered background (gradients, lines, grid, particles)
    CursorGlow.jsx          subtle desktop-only cursor glow
    Navbar.jsx              compacts on scroll
    Hero.jsx / HeroSystem.jsx
    ProjectsSection.jsx / ProjectPanel.jsx
    visuals/                 one custom animated SVG visual per project
    About.jsx
    Currently.jsx
    TechStack.jsx
    Contact.jsx
    Footer.jsx
  data/
    projects.js              project copy, kept separate from presentation
  App.jsx
  main.jsx
```

## Notes

- No GitHub link is included anywhere — add one in `Contact.jsx` (and the footer,
  if wanted) once you have a profile URL to share.
- Respects `prefers-reduced-motion`: background motion, parallax and cursor effects
  scale back automatically.
- Cursor glow and heavier motion are disabled on touch devices.
- All project visuals are custom SVG/CSS/Framer Motion — nothing is a real or
  fabricated screenshot.
