export const projects = [
  {
    id: "argus",
    index: "01",
    title: "Argus AI",
    subtitle: "AI-powered situational awareness & real-time understanding",
    description:
      "A multimodal computer-vision concept that tries to understand what's happening in a space instead of just labeling objects in it — restricted-zone entry, an unattended bag, a crowd building up, someone falling.",
    detail:
      "Feeds go through detection, tracking and temporal reasoning, then a vision-language step turns raw motion into a plain-language event: \"Person #12 entered restricted zone at 14:32.\" It's a hackathon-stage concept, not a deployed system — crowds still cause false alerts, occlusion throws off tracking, and the generated explanations aren't always right.",
    tags: [
      "Computer Vision",
      "Object Tracking",
      "Vision-Language Models",
      "Anomaly Detection",
      "WebSockets",
    ],
    visual: "argus",
  },
  {
    id: "answer-eval",
    index: "02",
    title: "Answer Evaluation System",
    subtitle: "AI-based automatic evaluation of descriptive answers",
    description:
      "Grades open-ended student answers by meaning rather than keyword overlap — a reference answer and a student's answer both get embedded, and the similarity between them becomes the score.",
    detail:
      "Sentence-transformer embeddings feed a semantic-similarity step, which produces a score and short AI-generated feedback through a teacher-facing Streamlit dashboard.",
    tags: ["Python", "Streamlit", "Sentence Transformers", "Hugging Face", "NLP"],
    visual: "answerEval",
  },
  {
    id: "smart-water",
    index: "03",
    title: "Smart Water Management",
    subtitle: "IoT + ML water management and alerts for agricultural fields",
    description:
      "Field sensors feed a microcontroller, which pushes readings to a database; a trained model turns that data into irrigation decisions and alerts.",
    detail:
      "Compared Decision Tree, Random Forest, SVM and ANN classifiers for the decision step — the ANN reached about 97% accuracy in the project's own evaluation, a reported benchmark rather than a real-world field result.",
    tags: ["IoT", "Sensors", "Machine Learning", "Cloud Storage"],
    visual: "smartWater",
  },
  {
    id: "hr-ops",
    index: "04",
    title: "HR Ops Management System",
    subtitle: "Employee records, attendance and leave in one workflow",
    description:
      "A practical ops tool for the parts of HR that are mostly bookkeeping — who's on what team, who's out, who approved it.",
    detail:
      "Employees roll up into departments, departments track attendance and leave requests, and the whole thing surfaces as a single workflow dashboard.",
    tags: ["Employee Records", "Attendance", "Workflow", "Dashboards"],
    visual: "hrOps",
  },
  {
    id: "devops",
    index: "05",
    title: "DevOps Monitoring Dashboard",
    subtitle: "Visibility into containers, clusters and deploys",
    description:
      "A monitoring concept for the infrastructure layer — containers, Kubernetes clusters, CPU and RAM, service health, what just got deployed.",
    detail:
      "Built around the idea that infrastructure state should be legible at a glance: server, containers, cluster, and the live metrics underneath all of it.",
    tags: ["Docker", "Kubernetes", "Monitoring", "Service Health"],
    visual: "devops",
  },
];
