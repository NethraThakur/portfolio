import { motion } from "framer-motion";
import SectionLabel from "./SectionLabel";

const groups = [
  { title: "Core", items: ["HTML5", "CSS3", "JavaScript", "Python", "Java"] },
  { title: "Web / Software", items: ["React", "Node.js", "Express", "Flask", "REST APIs", "Responsive Design"] },
  { title: "AI / ML", items: ["Machine Learning", "Computer Vision", "Sentence Transformers", "Hugging Face", "NLP"] },
  { title: "DevOps / Systems", items: ["Docker", "Kubernetes", "Monitoring", "Git", "GitHub"] },
  { title: "IoT", items: ["Sensors", "Microcontrollers", "Cloud Storage", "ML for IoT"] },
  { title: "Design / Tools", items: ["Figma", "Canva", "VS Code"] },
  { title: "Working with people", items: ["Client Communication", "Time Management", "Problem Solving", "Team Collaboration"] },
  { title: "Exploring", items: ["Backend Systems", "DSA", "Cloud & DevOps", "Quant / Fintech"] },
];

export default function TechStack() {
  return (
    <section id="stack" className="relative px-6 sm:px-10 py-20">
      <div className="mx-auto max-w-5xl">
        <SectionLabel index="04" label="WHAT I WORK WITH" />
        <h2 className="font-display text-3xl sm:text-4xl font-semibold mb-10 max-w-lg">
          A running list, not a mastery chart
        </h2>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-x-10 gap-y-8">
          {groups.map((g, gi) => (
            <motion.div
              key={g.title}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-10% 0px" }}
              transition={{ duration: 0.5, delay: gi * 0.05 }}
            >
              <p className="font-mono-label text-xs tracking-widest mb-3" style={{ color: "var(--ink-faint)" }}>
                {g.title}
              </p>
              <div className="flex flex-wrap gap-2">
                {g.items.map((it) => (
                  <span
                    key={it}
                    className="text-sm px-3 py-1.5 rounded-full transition-colors hover:opacity-100"
                    style={{ border: "1px solid var(--line)", color: "var(--ink-dim)" }}
                  >
                    {it}
                  </span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        <p className="mt-10 text-sm" style={{ color: "var(--ink-faint)" }}>
          Also comfortable managing socials and content — Instagram, Canva design, basic branding
          — from doing it for real projects alongside the code.
        </p>
      </div>
    </section>
  );
}
