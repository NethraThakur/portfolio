import { useEffect, useRef } from "react";

export default function CursorGlow() {
  const ref = useRef(null);

  useEffect(() => {
    const isTouch = window.matchMedia("(pointer: coarse)").matches;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (isTouch || reduced || !ref.current) return;

    const el = ref.current;
    let raf;
    const onMove = (e) => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        el.style.transform = `translate(${e.clientX - 90}px, ${e.clientY - 90}px)`;
        el.style.opacity = "1";
      });
    };
    window.addEventListener("mousemove", onMove);
    return () => window.removeEventListener("mousemove", onMove);
  }, []);

  return (
    <div
      ref={ref}
      aria-hidden="true"
      className="pointer-events-none fixed top-0 left-0 w-[180px] h-[180px] rounded-full opacity-0 hidden md:block -z-[5] transition-opacity duration-500"
      style={{
        background: "radial-gradient(circle, rgba(185,168,255,0.10), transparent 70%)",
        willChange: "transform",
      }}
    />
  );
}
