import SectionLabel from "./SectionLabel";
import ProjectPanel from "./ProjectPanel";
import { projects } from "../data/projects";

export default function ProjectsSection() {
  return (
    <section id="projects" className="relative px-6 sm:px-10 py-20">
      <div className="mx-auto max-w-5xl">
        <SectionLabel index="02" label="THINGS I'VE BUILT" />
        <h2 className="font-display text-4xl sm:text-5xl font-semibold mb-4 max-w-xl">
          Selected work
        </h2>
        <p className="max-w-lg text-[15px]" style={{ color: "var(--ink-dim)" }}>
          Five projects that actually shipped past the idea stage — spanning computer vision, NLP, IoT and infrastructure.
        </p>

        <div>
          {projects.map((p, i) => (
            <ProjectPanel key={p.id} project={p} reverse={i % 2 === 1} />
          ))}
        </div>
      </div>
    </section>
  );
}
