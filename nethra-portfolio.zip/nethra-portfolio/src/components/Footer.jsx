import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function Footer() {
  const [pulse, setPulse] = useState(false);

  return (
    <footer className="relative px-6 sm:px-10 py-10 text-center">
      <p className="text-xs mb-2" style={{ color: "var(--ink-faint)" }}>
        Built with curiosity &amp; questionable amounts of caffeine.
      </p>
      <p className="font-mono-label text-[11px] flex items-center justify-center gap-2" style={{ color: "var(--ink-faint)" }}>
        <button
          onClick={() => setPulse(true)}
          onAnimationEnd={() => {}}
          aria-label="hidden pixel"
          className="w-1.5 h-1.5 rounded-full inline-block"
          style={{ background: "var(--lavender)", opacity: 0.5 }}
        />
        2026 · Nethra Thakur
      </p>

      <AnimatePresence>
        {pulse && (
          <motion.span
            initial={{ opacity: 0.8, scale: 0.4 }}
            animate={{ opacity: 0, scale: 12 }}
            transition={{ duration: 1.1, ease: "easeOut" }}
            onAnimationComplete={() => setPulse(false)}
            className="pointer-events-none absolute left-1/2 bottom-8 -translate-x-1/2 w-2 h-2 rounded-full"
            style={{ background: "var(--cyan)" }}
          />
        )}
      </AnimatePresence>
    </footer>
  );
}
