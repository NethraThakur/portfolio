import { useState } from "react";
import { motion } from "framer-motion";
import ArgusVisual from "./visuals/ArgusVisual";
import AnswerEvalVisual from "./visuals/AnswerEvalVisual";
import SmartWaterVisual from "./visuals/SmartWaterVisual";
import HROpsVisual from "./visuals/HROpsVisual";
import DevOpsVisual from "./visuals/DevOpsVisual";

const VISUALS = {
  argus: ArgusVisual,
  answerEval: AnswerEvalVisual,
  smartWater: SmartWaterVisual,
  hrOps: HROpsVisual,
  devops: DevOpsVisual,
};

export default function ProjectPanel({ project, reverse }) {
  const [expanded, setExpanded] = useState(false);
  const Visual = VISUALS[project.visual];

  return (
    <div
      className={`flex flex-col ${reverse ? "md:flex-row-reverse" : "md:flex-row"} items-center gap-10 md:gap-16 py-16 md:py-24 border-t`}
      style={{ borderColor: "var(--line)" }}
    >
      <motion.div
        className="w-full md:w-[46%] aspect-[4/3] rounded-2xl p-4"
        style={{ background: "rgba(255,255,255,0.02)", border: "1px solid var(--line)" }}
        initial={{ opacity: 0.6, scale: 0.97 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: false, margin: "-10% 0px", amount: 0.5 }}
        transition={{ duration: 0.7, ease: "easeOut" }}
      >
        <Visual />
      </motion.div>

      <motion.div
        className="w-full md:w-[54%]"
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-15% 0px" }}
        transition={{ duration: 0.7, ease: "easeOut" }}
      >
        <div className="flex items-baseline gap-4 mb-3">
          <span className="font-mono-label text-sm" style={{ color: "var(--cyan)" }}>
            {project.index}
          </span>
          <h3 className="font-display text-2xl sm:text-3xl font-semibold">{project.title}</h3>
        </div>
        <p className="text-sm sm:text-base mb-4" style={{ color: "var(--ink-dim)" }}>
          {project.subtitle}
        </p>
        <p className="text-[15px] leading-relaxed mb-4 max-w-lg">{project.description}</p>

        {expanded && (
          <motion.p
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            className="text-[15px] leading-relaxed mb-4 max-w-lg"
            style={{ color: "var(--ink-dim)" }}
          >
            {project.detail}
          </motion.p>
        )}

        <button
          onClick={() => setExpanded((v) => !v)}
          className="font-mono-label text-xs tracking-widest mb-5 opacity-80 hover:opacity-100 flex items-center gap-2"
          style={{ color: "var(--lavender)" }}
        >
          {expanded ? "LESS" : "DETAILS"}
          <span className="transition-transform" style={{ transform: expanded ? "rotate(90deg)" : "none" }}>
            ›
          </span>
        </button>

        <div className="flex flex-wrap gap-2">
          {project.tags.map((t) => (
            <span
              key={t}
              className="font-mono-label text-[11px] px-2.5 py-1 rounded-full"
              style={{ border: "1px solid var(--line)", color: "var(--ink-faint)" }}
            >
              {t}
            </span>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
