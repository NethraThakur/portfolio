import { motion } from "framer-motion";
import SectionLabel from "./SectionLabel";

const stats = [
  { value: "2+", label: "years building" },
  { value: "9+", label: "projects" },
  { value: "2028", label: "graduating" },
];

export default function About() {
  return (
    <section id="about" className="relative px-6 sm:px-10 py-20">
      <div className="mx-auto max-w-5xl grid md:grid-cols-[1.3fr_1fr] gap-14">
        <div>
          <SectionLabel index="03" label="A LITTLE ABOUT ME" />
          <h2 className="font-display text-3xl sm:text-4xl font-semibold mb-6 max-w-lg">
            Just a CSE student who likes building things that probably started as a random idea at 2am.
          </h2>
          <p className="text-[15px] leading-relaxed max-w-lg" style={{ color: "var(--ink-dim)" }}>
            I'm currently exploring the intersection of AI/ML, software, IoT, DevOps and the
            systems underneath the things I use every day. I like learning by actually making
            things — sometimes polished, sometimes experimental, and occasionally held together
            by an unreasonable number of browser tabs.
          </p>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-10% 0px" }}
          transition={{ duration: 0.7 }}
          className="rounded-2xl p-6 h-fit"
          style={{ border: "1px solid var(--line)", background: "rgba(255,255,255,0.02)" }}
        >
          <p className="font-mono-label text-xs tracking-widest mb-5" style={{ color: "var(--ink-faint)" }}>
            EDUCATION
          </p>
          <p className="font-display font-semibold mb-1">B.Tech — CSE (AI &amp; ML)</p>
          <p className="text-sm mb-5" style={{ color: "var(--ink-dim)" }}>
            Institute of Aeronautical Engineering, Hyderabad
          </p>

          <div className="grid grid-cols-3 gap-3 text-sm mb-6">
            <div>
              <p className="font-display font-semibold">8.0</p>
              <p className="text-[11px]" style={{ color: "var(--ink-faint)" }}>CGPA /10</p>
            </div>
            <div>
              <p className="font-display font-semibold">96.7%</p>
              <p className="text-[11px]" style={{ color: "var(--ink-faint)" }}>12th</p>
            </div>
            <div>
              <p className="font-display font-semibold">90%</p>
              <p className="text-[11px]" style={{ color: "var(--ink-faint)" }}>10th</p>
            </div>
          </div>

          <div className="flex gap-6 pt-5" style={{ borderTop: "1px solid var(--line)" }}>
            {stats.map((s) => (
              <div key={s.label}>
                <p className="font-display text-xl font-semibold" style={{ color: "var(--lavender)" }}>
                  {s.value}
                </p>
                <p className="text-[11px]" style={{ color: "var(--ink-faint)" }}>{s.label}</p>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
