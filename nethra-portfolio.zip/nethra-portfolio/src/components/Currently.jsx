import { motion } from "framer-motion";

const items = [
  "Building projects",
  "Learning DSA",
  "Exploring AI/ML",
  "Getting deeper into backend systems",
  "Experimenting with new ideas",
  "Collecting way too many browser tabs",
];

export default function Currently() {
  return (
    <section className="relative px-6 sm:px-10 py-16">
      <div className="mx-auto max-w-5xl">
        <p className="font-mono-label text-xs tracking-[0.2em] mb-6" style={{ color: "var(--ink-faint)" }}>
          CURRENTLY
        </p>
        <div className="grid sm:grid-cols-2 gap-x-10 gap-y-3">
          {items.map((text, i) => (
            <motion.div
              key={text}
              initial={{ opacity: 0, x: -14 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-10% 0px" }}
              transition={{ duration: 0.5, delay: i * 0.08 }}
              className="flex items-center gap-3"
            >
              <span className="font-mono-label text-sm" style={{ color: "var(--cyan)" }}>
                →
              </span>
              <span className="text-[15px]" style={{ color: "var(--ink-dim)" }}>
                {text}
              </span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
