import { motion } from "framer-motion";
import HeroSystem from "./HeroSystem";

const container = {
  hidden: {},
  show: {
    transition: { staggerChildren: 0.16, delayChildren: 0.15 },
  },
};

const item = {
  hidden: { opacity: 0, y: 22 },
  show: { opacity: 1, y: 0, transition: { duration: 0.8, ease: [0.16, 1, 0.3, 1] } },
};

export default function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center px-6 sm:px-10 pt-28 pb-16">
      <motion.div
        className="mx-auto w-full max-w-6xl flex flex-col-reverse md:flex-row items-center md:items-end justify-between gap-12"
        variants={container}
        initial="hidden"
        animate="show"
      >
        <div className="max-w-2xl">
          <motion.p variants={item} className="font-mono-label text-xs tracking-[0.2em] mb-5" style={{ color: "var(--cyan)" }}>
            CSE (AI &amp; ML) · builder · curious about everything tech
          </motion.p>

          <motion.h1
            variants={item}
            className="font-display font-semibold leading-[0.95] text-[15vw] sm:text-[6.5rem] md:text-[5.5rem] lg:text-[6.4rem]"
          >
            Nethra
            <br />
            Thakur
          </motion.h1>

          <motion.p variants={item} className="mt-6 text-lg sm:text-xl max-w-lg" style={{ color: "var(--ink-dim)" }}>
            Currently building things with AI, code &amp; way too many browser tabs.
          </motion.p>

          <motion.div variants={item} className="mt-8 flex flex-wrap gap-x-5 gap-y-2 font-mono-label text-xs tracking-widest" style={{ color: "var(--ink-faint)" }}>
            <span>AI/ML</span>
            <span>SOFTWARE</span>
            <span>IoT</span>
            <span>DEVOPS</span>
            <span>WEB</span>
          </motion.div>
        </div>

        <motion.div variants={item}>
          <HeroSystem />
        </motion.div>
      </motion.div>

      <motion.a
        href="#projects"
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.6, duration: 1 }}
        aria-label="Scroll to projects"
      >
        <span className="font-mono-label text-[10px] tracking-[0.2em]" style={{ color: "var(--ink-faint)" }}>
          SCROLL
        </span>
        <motion.span
          className="w-px h-8"
          style={{ background: "linear-gradient(to bottom, var(--lavender), transparent)" }}
          animate={{ scaleY: [1, 0.6, 1] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
        />
      </motion.a>
    </section>
  );
}
