import { motion } from "framer-motion";

const ATMOSPHERES = {
  hero: { a: "#2b3a8c", b: "#4d3aa0", c: "#1c2456" },
  projects: { a: "#3a2f80", b: "#5b3ab0", c: "#232d6e" },
  about: { a: "#33417f", b: "#6a5bc2", c: "#2a3568" },
  stack: { a: "#3d4a92", b: "#7a5fd0", c: "#2f3a78" },
  contact: { a: "#5a3f7f", b: "#8a5fb0", c: "#6a4568" },
};

const PARTICLES = [
  { top: "18%", left: "12%", delay: 0, px: "18px" },
  { top: "64%", left: "22%", delay: 4, px: "-14px" },
  { top: "34%", left: "78%", delay: 8, px: "12px" },
  { top: "78%", left: "68%", delay: 2, px: "-20px" },
  { top: "50%", left: "48%", delay: 11, px: "8px" },
];

export default function AmbientBackground({ atmosphere = "hero" }) {
  const tone = ATMOSPHERES[atmosphere] ?? ATMOSPHERES.hero;
  const transition = { duration: 1.8, ease: "easeInOut" };

  return (
    <div
      aria-hidden="true"
      className="fixed inset-0 -z-10 overflow-hidden"
      style={{ background: "var(--bg)" }}
    >
      {/* layer 1 — slow blurred gradient shapes */}
      <motion.div
        className="amb-blob absolute w-[60vw] h-[60vw] rounded-full opacity-40"
        style={{ top: "-10%", left: "-10%", filter: "blur(90px)", animation: "drift-a 46s ease-in-out infinite" }}
        animate={{ backgroundColor: tone.a }}
        transition={transition}
      />
      <motion.div
        className="amb-blob absolute w-[50vw] h-[50vw] rounded-full opacity-30"
        style={{ bottom: "-15%", right: "-10%", filter: "blur(100px)", animation: "drift-b 58s ease-in-out infinite" }}
        animate={{ backgroundColor: tone.b }}
        transition={transition}
      />
      <motion.div
        className="amb-blob absolute w-[40vw] h-[40vw] rounded-full opacity-30"
        style={{ top: "38%", left: "55%", filter: "blur(80px)", animation: "drift-c 52s ease-in-out infinite" }}
        animate={{ backgroundColor: tone.c }}
        transition={transition}
      />

      {/* layer 2 — thin flowing pathways */}
      <svg className="absolute inset-0 w-full h-full opacity-[0.14]" viewBox="0 0 1200 800" preserveAspectRatio="xMidYMid slice">
        <path d="M-50,600 C 250,500 350,720 650,560 S 1050,420 1260,520" fill="none" stroke="url(#lineGrad)" strokeWidth="1.2" />
        <path d="M-50,220 C 200,320 420,140 700,260 S 1000,180 1260,120" fill="none" stroke="url(#lineGrad)" strokeWidth="1" />
        <path d="M-50,420 C 280,380 520,480 760,400 S 1080,300 1260,360" fill="none" stroke="url(#lineGrad)" strokeWidth="0.8" />
        <defs>
          <linearGradient id="lineGrad" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="var(--cyan)" stopOpacity="0" />
            <stop offset="50%" stopColor="var(--lavender)" stopOpacity="0.9" />
            <stop offset="100%" stopColor="var(--blue)" stopOpacity="0" />
          </linearGradient>
        </defs>
      </svg>

      {/* layer 4 — faint shifting dot grid */}
      <div
        className="amb-grid absolute inset-0 opacity-60"
        style={{
          backgroundImage:
            "radial-gradient(circle, var(--grid) 1px, transparent 1px)",
          backgroundSize: "32px 32px",
          animation: "grid-shift 34s linear infinite",
        }}
      />

      {/* layer 3 — a few floating particles */}
      {PARTICLES.map((p, i) => (
        <span
          key={i}
          className="amb-particle absolute w-[3px] h-[3px] rounded-full"
          style={{
            top: p.top,
            left: p.left,
            background: "var(--lavender)",
            boxShadow: "0 0 6px 1px var(--lavender)",
            "--px": p.px,
            animation: `particle-float ${18 + i * 3}s ease-in-out ${p.delay}s infinite`,
          }}
        />
      ))}

      {/* layer 5 — occasional soft light trail */}
      <div
        className="amb-trail absolute top-[20%] left-0 w-[36vw] h-px opacity-0"
        style={{
          background:
            "linear-gradient(90deg, transparent, var(--cyan), transparent)",
          animation: "trail-sweep 26s ease-in-out infinite",
          animationDelay: "6s",
        }}
      />

      {/* layer 7 — tiny system labels */}
      <span
        className="amb-label font-mono-label absolute text-[10px] tracking-widest opacity-0 hidden sm:block"
        style={{ top: "14%", right: "8%", color: "var(--ink-faint)", animation: "label-fade 22s ease-in-out infinite" }}
      >
        SYSTEM / ONLINE
      </span>
      <span
        className="amb-label font-mono-label absolute text-[10px] tracking-widest opacity-0 hidden sm:block"
        style={{ bottom: "16%", left: "6%", color: "var(--ink-faint)", animation: "label-fade 27s ease-in-out infinite", animationDelay: "9s" }}
      >
        41.9 / -12.3
      </span>

      {/* layer 6 — subtle film grain */}
      <svg className="absolute inset-0 w-full h-full opacity-[0.035] mix-blend-overlay">
        <filter id="grain">
          <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves="2" stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" />
      </svg>

      {/* vignette so content stays readable */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(120% 100% at 50% 0%, transparent 40%, rgba(6,7,14,0.55) 100%)",
        }}
      />
    </div>
  );
}
