import { useEffect, useState } from "react";
import { motion } from "framer-motion";

const LINKS = [
  { href: "#home", label: "Home" },
  { href: "#projects", label: "Projects" },
  { href: "#about", label: "About" },
  { href: "#stack", label: "Stack" },
  { href: "#contact", label: "Contact" },
];

export default function Navbar() {
  const [compact, setCompact] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setCompact(window.scrollY > 60);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      className="fixed top-0 inset-x-0 z-40 flex justify-center"
      initial={{ y: -40, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }}
    >
      <nav
        className="flex items-center justify-between w-full transition-all duration-500"
        style={{
          maxWidth: compact ? "760px" : "1120px",
          margin: compact ? "12px 16px 0" : "20px 16px 0",
          padding: compact ? "10px 20px" : "16px 24px",
          borderRadius: "999px",
          background: compact ? "rgba(15,17,32,0.72)" : "rgba(15,17,32,0.28)",
          border: "1px solid var(--line)",
          backdropFilter: "blur(14px)",
        }}
      >
        <a href="#home" className="font-display font-semibold text-sm sm:text-base tracking-tight">
          Nethra Thakur
        </a>

        <ul className="hidden md:flex items-center gap-7 text-sm">
          {LINKS.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className="relative opacity-80 hover:opacity-100 transition-opacity group"
              >
                {l.label}
                <span className="absolute -bottom-1 left-0 h-px w-0 group-hover:w-full transition-all duration-300" style={{ background: "var(--lavender)" }} />
              </a>
            </li>
          ))}
        </ul>

        <button
          className="md:hidden flex flex-col gap-1.5 p-1"
          aria-label="Toggle menu"
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
        >
          <span className="w-5 h-px bg-current" />
          <span className="w-5 h-px bg-current" />
        </button>
      </nav>

      {open && (
        <motion.ul
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:hidden absolute top-[70px] right-4 flex flex-col gap-1 text-sm rounded-2xl overflow-hidden"
          style={{ background: "rgba(15,17,32,0.92)", border: "1px solid var(--line)", backdropFilter: "blur(14px)" }}
        >
          {LINKS.map((l) => (
            <li key={l.href}>
              <a href={l.href} className="block px-6 py-3" onClick={() => setOpen(false)}>
                {l.label}
              </a>
            </li>
          ))}
        </motion.ul>
      )}
    </motion.header>
  );
}
