export default function DevOpsVisual() {
  const containers = [70, 150, 230];
  return (
    <svg viewBox="0 0 400 260" className="w-full h-full" role="img" aria-label="Animated diagram of a server feeding containers into a Kubernetes cluster with live CPU, RAM and service metrics">
      <rect x="150" y="25" width="100" height="30" rx="6" fill="none" stroke="var(--blue)" strokeWidth="1.2" />
      <text x="200" y="45" textAnchor="middle" className="font-mono-label" fontSize="8" fill="var(--ink-dim)">SERVER</text>

      {containers.map((x, i) => (
        <g key={i}>
          <line x1="200" y1="55" x2={x + 20} y2="95" stroke="var(--line)" strokeWidth="1" />
          <rect x={x} y="95" width="40" height="30" rx="5" fill="none" stroke="var(--cyan)" strokeWidth="1">
            <animate attributeName="stroke-opacity" values="0.4;1;0.4" dur="3.5s" begin={`${i * 0.5}s`} repeatCount="indefinite" />
          </rect>
          <text x={x + 20} y="115" textAnchor="middle" className="font-mono-label" fontSize="6.5" fill="var(--ink-faint)">
            C{i + 1}
          </text>
        </g>
      ))}

      <line x1="90" y1="125" x2="200" y2="160" stroke="var(--line)" strokeWidth="1" />
      <line x1="170" y1="125" x2="200" y2="160" stroke="var(--line)" strokeWidth="1" />
      <line x1="250" y1="125" x2="200" y2="160" stroke="var(--line)" strokeWidth="1" />

      <rect x="140" y="160" width="120" height="30" rx="8" fill="none" stroke="var(--purple)" strokeWidth="1.2" />
      <text x="200" y="180" textAnchor="middle" className="font-mono-label" fontSize="8" fill="var(--ink-dim)">
        KUBERNETES
      </text>

      {/* deployment event traveling down */}
      <circle r="3" fill="var(--lavender)">
        <animateMotion dur="4s" repeatCount="indefinite" path="M200,55 L200,175" />
      </circle>

      {/* metrics row */}
      {[
        { x: 60, label: "CPU 42%" },
        { x: 160, label: "RAM 61%" },
        { x: 260, label: "SERVICE OK" },
        { x: 360, label: "DEPLOY v1.4" },
      ].map((m, i) => (
        <text key={i} x={m.x} y="225" textAnchor="middle" className="font-mono-label" fontSize="7" fill="var(--ink-faint)" opacity="0.7">
          {m.label}
          <animate attributeName="opacity" values="0.4;0.9;0.4" dur="3s" begin={`${i * 0.6}s`} repeatCount="indefinite" />
        </text>
      ))}
    </svg>
  );
}
