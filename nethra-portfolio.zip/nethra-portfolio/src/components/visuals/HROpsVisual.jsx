export default function HROpsVisual() {
  return (
    <svg viewBox="0 0 400 260" className="w-full h-full" role="img" aria-label="Animated diagram of employee, department, attendance and leave nodes connected in a workflow">
      {/* employee -> department */}
      <line x1="200" y1="55" x2="200" y2="100" stroke="var(--line)" strokeWidth="1" />
      <circle cx="200" cy="45" r="12" fill="none" stroke="var(--lavender)" strokeWidth="1.2" />
      <text x="200" y="30" textAnchor="middle" className="font-mono-label" fontSize="7.5" fill="var(--ink-faint)">EMPLOYEES</text>

      <circle cx="200" cy="115" r="12" fill="none" stroke="var(--blue)" strokeWidth="1.2" />
      <text x="200" y="140" textAnchor="middle" className="font-mono-label" fontSize="7.5" fill="var(--ink-faint)">DEPARTMENTS</text>

      {/* branch to attendance / leave / workflow */}
      <line x1="200" y1="127" x2="100" y2="185" stroke="var(--line)" strokeWidth="1" />
      <line x1="200" y1="127" x2="200" y2="185" stroke="var(--line)" strokeWidth="1" />
      <line x1="200" y1="127" x2="300" y2="185" stroke="var(--line)" strokeWidth="1" />

      {[
        { x: 100, label: "ATTENDANCE" },
        { x: 200, label: "LEAVE" },
        { x: 300, label: "WORKFLOW" },
      ].map((n, i) => (
        <g key={i}>
          <rect x={n.x - 30} y="185" width="60" height="26" rx="8" fill="none" stroke="var(--cyan)" strokeWidth="1">
            <animate attributeName="opacity" values="0.5;1;0.5" dur="5s" begin={`${i * 0.7}s`} repeatCount="indefinite" />
          </rect>
          <text x={n.x} y="202" textAnchor="middle" className="font-mono-label" fontSize="7" fill="var(--ink-dim)">
            {n.label}
          </text>
        </g>
      ))}

      {/* traveling status pulses */}
      {[[100, 185], [200, 185], [300, 185]].map(([x, y], i) => (
        <circle key={i} r="2.4" fill="var(--lavender)">
          <animateMotion dur={`${4 + i}s`} repeatCount="indefinite" path={`M200,127 L${x},${y}`} />
        </circle>
      ))}
    </svg>
  );
}
