const nodes = [
  { x: 45, label: "SENSOR" },
  { x: 155, label: "DATA" },
  { x: 265, label: "ML MODEL" },
  { x: 355, label: "IRRIGATION" },
];

export default function SmartWaterVisual() {
  return (
    <svg viewBox="0 0 400 260" className="w-full h-full" role="img" aria-label="Animated diagram of sensor data flowing through a machine learning model into an irrigation decision">
      <line x1="45" y1="130" x2="355" y2="130" stroke="var(--line)" strokeWidth="1" />

      {nodes.map((n, i) => (
        <g key={i}>
          <circle cx={n.x} cy="130" r="14" fill="none" stroke="var(--blue)" strokeWidth="1.2">
            <animate attributeName="r" values="14;16;14" dur="4s" begin={`${i * 0.4}s`} repeatCount="indefinite" />
          </circle>
          <circle cx={n.x} cy="130" r="4" fill="var(--cyan)" opacity="0.8" />
          <text x={n.x} y="160" textAnchor="middle" className="font-mono-label" fontSize="7.5" fill="var(--ink-faint)">
            {n.label}
          </text>
        </g>
      ))}

      {/* flowing data particles between nodes */}
      {[0, 1, 2].map((i) => (
        <circle key={i} r="2.6" fill="var(--lavender)">
          <animateMotion
            dur="3.2s"
            begin={`${i * 1.1}s`}
            repeatCount="indefinite"
            path={`M${nodes[i].x},130 L${nodes[i + 1].x},130`}
          />
        </circle>
      ))}

      {/* droplets rising near the sensor to suggest the field */}
      {[0, 1, 2].map((i) => (
        <circle key={`d${i}`} cx={30 + i * 12} cy="200" r="2" fill="var(--cyan)" opacity="0.5">
          <animate attributeName="cy" values="205;110;205" dur={`${5 + i}s`} begin={`${i * 1.5}s`} repeatCount="indefinite" />
          <animate attributeName="opacity" values="0;0.6;0" dur={`${5 + i}s`} begin={`${i * 1.5}s`} repeatCount="indefinite" />
        </circle>
      ))}

      <text x="355" y="90" textAnchor="middle" className="font-mono-label" fontSize="8" fill="var(--ink-faint)">
        ANN ~97% <tspan fill="var(--ink-faint)" fontSize="6.5">(reported)</tspan>
      </text>
    </svg>
  );
}
