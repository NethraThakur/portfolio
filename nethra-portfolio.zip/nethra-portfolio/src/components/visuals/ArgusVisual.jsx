export default function ArgusVisual() {
  return (
    <svg viewBox="0 0 400 260" className="w-full h-full" role="img" aria-label="Animated diagram of Argus AI tracking entities within a camera frame and flagging a zone event">
      <rect x="20" y="20" width="360" height="220" rx="10" fill="none" stroke="var(--line)" strokeWidth="1" />
      {/* corner ticks */}
      <path d="M20,34 V20 H34" stroke="var(--cyan)" strokeWidth="1.4" fill="none" opacity="0.6" />
      <path d="M366,20 H380 V34" stroke="var(--cyan)" strokeWidth="1.4" fill="none" opacity="0.6" />
      <path d="M20,226 V240 H34" stroke="var(--cyan)" strokeWidth="1.4" fill="none" opacity="0.6" />
      <path d="M366,240 H380 V226" stroke="var(--cyan)" strokeWidth="1.4" fill="none" opacity="0.6" />

      {/* restricted zone */}
      <rect x="250" y="150" width="90" height="70" fill="var(--purple)" opacity="0.08" stroke="var(--purple)" strokeDasharray="4 4" strokeWidth="1">
        <animate attributeName="opacity" values="0.08;0.18;0.08" dur="4s" repeatCount="indefinite" />
      </rect>
      <text x="255" y="146" className="font-mono-label" fontSize="8" fill="var(--purple)">ZONE / A</text>

      {/* scanning line */}
      <rect x="20" y="20" width="360" height="2" fill="var(--cyan)" opacity="0.5">
        <animate attributeName="y" values="20;238;20" dur="6s" repeatCount="indefinite" />
      </rect>

      {/* entity 1 with tracking trail, moving toward the zone */}
      <g>
        <circle r="4" fill="var(--lavender)">
          <animateMotion dur="9s" repeatCount="indefinite" path="M60,60 C 140,90 220,130 295,185" />
        </circle>
        <text className="font-mono-label" fontSize="7" fill="var(--ink-dim)">
          <animateMotion dur="9s" repeatCount="indefinite" path="M72,58 C 152,88 232,128 307,183" />
          #12
        </text>
      </g>

      {/* entity 2, static wander */}
      <circle r="3.4" fill="var(--blue)">
        <animateMotion dur="13s" repeatCount="indefinite" path="M330,60 C 300,90 260,70 230,95 260,120 300,100 330,60" />
      </circle>

      {/* event callout */}
      <g>
        <rect x="130" y="228" width="150" height="1" fill="none" />
        <text x="140" y="205" className="font-mono-label" fontSize="9" fill="var(--cyan)" opacity="0">
          <animate attributeName="opacity" values="0;0;1;1;0" dur="9s" keyTimes="0;0.75;0.82;0.94;1" repeatCount="indefinite" />
          EVENT DETECTED
        </text>
        <text x="140" y="218" className="font-mono-label" fontSize="8" fill="var(--ink)" opacity="0">
          <animate attributeName="opacity" values="0;0;1;1;0" dur="9s" keyTimes="0;0.8;0.86;0.96;1" repeatCount="indefinite" />
          Person #12 entered Zone A
        </text>
      </g>
    </svg>
  );
}
