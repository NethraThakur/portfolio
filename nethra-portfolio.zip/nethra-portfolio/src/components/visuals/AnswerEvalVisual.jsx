const refLines = [78, 108, 138, 168];
const stuLines = [88, 118, 148, 178];

export default function AnswerEvalVisual() {
  return (
    <svg viewBox="0 0 400 260" className="w-full h-full" role="img" aria-label="Animated diagram of semantic similarity lines connecting a reference answer to a student answer, producing a score">
      <text x="30" y="52" className="font-mono-label" fontSize="8" fill="var(--ink-faint)">REFERENCE</text>
      <text x="270" y="52" className="font-mono-label" fontSize="8" fill="var(--ink-faint)">STUDENT ANSWER</text>

      {refLines.map((y, i) => (
        <rect key={`r${i}`} x="30" y={y} width={60 + (i % 2) * 20} height="6" rx="3" fill="var(--ink-faint)" opacity="0.35" />
      ))}
      {stuLines.map((y, i) => (
        <rect key={`s${i}`} x="270" y={y} width={60 + ((i + 1) % 2) * 20} height="6" rx="3" fill="var(--ink-faint)" opacity="0.35" />
      ))}

      {/* connecting semantic lines with moving embeddings */}
      {[0, 1, 2].map((i) => {
        const y1 = refLines[i] + 3;
        const y2 = stuLines[i] + 3;
        return (
          <g key={i}>
            <path
              id={`path-${i}`}
              d={`M96,${y1} C 170,${(y1 + y2) / 2} 230,${(y1 + y2) / 2} 270,${y2}`}
              fill="none"
              stroke="var(--cyan)"
              strokeWidth="0.8"
              opacity="0.4"
            />
            <circle r="2.6" fill="var(--lavender)">
              <animateMotion dur={`${5 + i}s`} repeatCount="indefinite" path={`M96,${y1} C 170,${(y1 + y2) / 2} 230,${(y1 + y2) / 2} 270,${y2}`} />
            </circle>
          </g>
        );
      })}

      {/* similarity readout */}
      <text x="150" y="220" className="font-mono-label" fontSize="9" fill="var(--ink-faint)">SIMILARITY</text>
      <text x="150" y="238" className="font-mono-label font-semibold" fontSize="15" fill="var(--cyan)">
        82%
        <animate attributeName="opacity" values="0.6;1;0.6" dur="3s" repeatCount="indefinite" />
      </text>
      <text x="240" y="220" className="font-mono-label" fontSize="9" fill="var(--ink-faint)">SCORE</text>
      <text x="240" y="238" className="font-mono-label font-semibold" fontSize="15" fill="var(--lavender)">8.2/10</text>
    </svg>
  );
}
