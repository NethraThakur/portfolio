import { useRef, useState } from "react";
import { motion } from "framer-motion";
import { Mail, ArrowUpRight, AtSign } from "lucide-react";

const links = [
  { href: "mailto:nethrathakur40@gmail.com", label: "nethrathakur40@gmail.com", icon: Mail },
  { href: "https://www.linkedin.com/in/nethra-thakur/", label: "LinkedIn", icon: ArrowUpRight },
  { href: "https://instagram.com/nethra.in", label: "Instagram", icon: AtSign },
];

export default function Contact() {
  const ref = useRef(null);
  const [pos, setPos] = useState({ x: 50, y: 50 });

  const handleMove = (e) => {
    const rect = ref.current?.getBoundingClientRect();
    if (!rect) return;
    setPos({
      x: ((e.clientX - rect.left) / rect.width) * 100,
      y: ((e.clientY - rect.top) / rect.height) * 100,
    });
  };

  return (
    <section
      id="contact"
      ref={ref}
      onMouseMove={handleMove}
      className="relative px-6 sm:px-10 py-28 sm:py-36 overflow-hidden"
    >
      <div
        className="absolute inset-0 pointer-events-none transition-[background] duration-300 hidden sm:block"
        style={{
          background: `radial-gradient(500px circle at ${pos.x}% ${pos.y}%, rgba(185,168,255,0.10), transparent 70%)`,
        }}
        aria-hidden="true"
      />

      <div className="relative mx-auto max-w-3xl text-center">
        <motion.h2
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="font-display text-4xl sm:text-6xl font-semibold mb-6"
        >
          Okay, your turn.
        </motion.h2>
        <motion.p
          initial={{ opacity: 0, y: 14 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="text-[15px] sm:text-lg max-w-md mx-auto mb-12"
          style={{ color: "var(--ink-dim)" }}
        >
          I'm always interested in interesting ideas, projects, collaborations, and things worth building.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 14 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          {links.map(({ href, label, icon: Icon }) => (
            <a
              key={label}
              href={href}
              target={href.startsWith("http") ? "_blank" : undefined}
              rel={href.startsWith("http") ? "noreferrer" : undefined}
              className="group flex items-center gap-2.5 px-5 py-3 rounded-full text-sm transition-colors"
              style={{ border: "1px solid var(--line)" }}
            >
              <Icon size={15} style={{ color: "var(--lavender)" }} />
              {label}
            </a>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
