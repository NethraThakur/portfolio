import { motion } from "framer-motion";

export default function HeroSystem() {
  return (
    <div className="relative w-[220px] h-[220px] sm:w-[260px] sm:h-[260px] shrink-0" aria-hidden="true">
      <svg viewBox="0 0 240 240" className="w-full h-full">
        <circle cx="120" cy="120" r="70" fill="none" stroke="var(--line)" strokeWidth="1" />
        <circle cx="120" cy="120" r="46" fill="none" stroke="var(--line)" strokeWidth="1" strokeDasharray="2 6" />
        <circle cx="120" cy="120" r="3" fill="var(--lavender)">
          <animate attributeName="opacity" values="0.4;1;0.4" dur="3.2s" repeatCount="indefinite" />
        </circle>

        {/* orbiting nodes */}
        <g>
          <circle cx="190" cy="120" r="4" fill="var(--cyan)">
            <animateTransform
              attributeName="transform"
              type="rotate"
              from="0 120 120"
              to="360 120 120"
              dur="22s"
              repeatCount="indefinite"
            />
          </circle>
          <circle cx="120" cy="50" r="3" fill="var(--blue)">
            <animateTransform
              attributeName="transform"
              type="rotate"
              from="0 120 120"
              to="-360 120 120"
              dur="30s"
              repeatCount="indefinite"
            />
          </circle>
          <circle cx="74" cy="166" r="2.5" fill="var(--purple)">
            <animateTransform
              attributeName="transform"
              type="rotate"
              from="0 120 120"
              to="360 120 120"
              dur="17s"
              repeatCount="indefinite"
            />
          </circle>
        </g>

        {/* connecting pulse lines */}
        <line x1="120" y1="120" x2="190" y2="120" stroke="var(--lavender)" strokeWidth="0.6" opacity="0.35" />
        <line x1="120" y1="120" x2="120" y2="50" stroke="var(--lavender)" strokeWidth="0.6" opacity="0.25" />
      </svg>

      <motion.span
        className="font-mono-label absolute -bottom-1 left-1/2 -translate-x-1/2 text-[9px] tracking-[0.25em]"
        style={{ color: "var(--ink-faint)" }}
        animate={{ opacity: [0.3, 0.7, 0.3] }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
      >
        NETHRA.SYS
      </motion.span>
    </div>
  );
}
