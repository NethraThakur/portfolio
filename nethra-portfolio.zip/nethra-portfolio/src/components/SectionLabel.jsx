import { motion } from "framer-motion";

export default function SectionLabel({ index, label }) {
  return (
    <motion.div
      className="flex items-center gap-3 mb-6"
      initial={{ opacity: 0, x: -8 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true, margin: "-15% 0px" }}
      transition={{ duration: 0.6, ease: "easeOut" }}
    >
      <span className="font-mono-label text-xs" style={{ color: "var(--cyan)" }}>
        {index}
      </span>
      <span className="h-px w-8" style={{ background: "var(--line)" }} />
      <span className="font-mono-label text-xs tracking-[0.2em]" style={{ color: "var(--ink-faint)" }}>
        {label}
      </span>
    </motion.div>
  );
}
