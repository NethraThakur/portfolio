import { useEffect, useState } from "react";
import AmbientBackground from "./components/AmbientBackground";
import CursorGlow from "./components/CursorGlow";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import ProjectsSection from "./components/ProjectsSection";
import About from "./components/About";
import Currently from "./components/Currently";
import TechStack from "./components/TechStack";
import Contact from "./components/Contact";
import Footer from "./components/Footer";

const SECTION_ATMOSPHERES = [
  { id: "home", tone: "hero" },
  { id: "projects", tone: "projects" },
  { id: "about", tone: "about" },
  { id: "stack", tone: "stack" },
  { id: "contact", tone: "contact" },
];

export default function App() {
  const [atmosphere, setAtmosphere] = useState("hero");

  useEffect(() => {
    const elements = SECTION_ATMOSPHERES
      .map((s) => ({ ...s, el: document.getElementById(s.id) }))
      .filter((s) => s.el);

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible) {
          const match = elements.find((s) => s.el === visible.target);
          if (match) setAtmosphere(match.tone);
        }
      },
      { threshold: [0.25, 0.5, 0.75] }
    );

    elements.forEach((s) => observer.observe(s.el));
    return () => observer.disconnect();
  }, []);

  return (
    <>
      <AmbientBackground atmosphere={atmosphere} />
      <CursorGlow />
      <Navbar />
      <main>
        <Hero />
        <ProjectsSection />
        <About />
        <Currently />
        <TechStack />
        <Contact />
      </main>
      <Footer />
    </>
  );
}
